// Noah | 26 Feb 2026 | Timeline
void setup() {
  size(950,400);
}
void draw() {
  background(#DB350B);
  drawRef();
  histEvent(150,200, "Dec 20, 2014", true,"Kylian Mbappé scores his first professional goal for AS Monaco FC, showing early signs of his immense talent.");
  histEvent(190,300, "Dec 2, 2015", false,"Debuts at 16 for Monaco, becoming the clubs youngest first-team player.");
  histEvent(330,200, "May 17, 2017", true,"Scores 15 goals to help Monaco win the league over Paris Saint-Germain FC.");
  histEvent(370,300, "Aug 31, 2017", false,"Signs with PSG in a €180M deal, becoming one of the most expensive teenage players ever." );
  histEvent(525,200, "July 15, 2018", true,"Wins the 2018 FIFA World Cup with the France national football team, scoring in the final at just 19.");
    histEvent(735,300, "Dec 18, 2022", false,"Finishes the season with 33 league goals.");
  histEvent(590,300, "May 19, 2019", false,"Scores a hat trick in the 2022 FIFA World Cup Final and wins the Golden Boot.");
  histEvent(800,200, "June 3, 2024", true,"Joins Real Madrid CF, beginning a new chapter at one of footballs biggest clubs.");
  
}  
void drawRef() {
  textAlign(CENTER);
  textSize(30);
  fill(#0B40DB);
 text("Kylian Mbappe Timeline", width/2,70);
 textSize(20);
 text("By: Noah Kergaye", width/2,100);
 strokeWeight(3);
 stroke(#0096F5);
 line(50,250,900,250);
 line(50,245,50,255);
 line(900,255,900,245);
 line(475,255,475,245);
 line(262.5,255,262.5,245);
 line(687.5,255,687.5,245);
 strokeWeight(2);
 fill(#A3804F);
 text("2010",50,270);
 text("2025",900,270);

 }
void histEvent(int x, int y, String title, boolean top, String detail) {
  if(top==true) {
    line(x,y,x-50,y+50);
  }else{
    line(x,y,x-50,y-50);
  }
 
 rectMode(CENTER);
 fill(#865C33);
 rect(x,y,110,30,10);
 fill(#0B63DB);
 textSize(20);
 text(title,x,y+5);
 if(mouseX > x-50 && mouseX < x+50 && mouseY > y-15 && mouseY < y+15) {
   textSize(16);
  text(detail,width/2,350);
  
  }

}
